﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pclasses
{
    public partial class frmHorista : Form
    {
        public frmHorista()
        {
            InitializeComponent();
        }

        private void btnInstanciar_Click(object sender, EventArgs e)
        {
            Horista ObjHorista = new Horista();

            ObjHorista.NomeEmpregado = txtNome.Text;
            ObjHorista.Matricula = Convert.ToInt32(txtMatricula.Text);
            ObjHorista.SalarioHora = Convert.ToDouble(txtSalario.Text);
            ObjHorista.NumeroHora = Convert.ToDouble(txtNumHora.Text);
            ObjHorista.DataEntradaEmpresa = Convert.ToDateTime(txtDataEntrada.Text);
            ObjHorista.DiasFalta = Convert.ToInt32(txtDiasFalta.Text);

            MessageBox.Show("Nome = " + ObjHorista.NomeEmpregado + "\n" +
               "Matrícula = " + ObjHorista.Matricula + "\n" +
               "Tempo de trabalho: " + ObjHorista.TempoTrabalho().ToString() +
               "\n" + "Salário final = " +
               ObjHorista.SalarioBruto().ToString("N2"));

            MessageBox.Show($"Salário com aumento: {ObjHorista.SalarioBruto(50).ToString("N2")}");
        }
    }
}
